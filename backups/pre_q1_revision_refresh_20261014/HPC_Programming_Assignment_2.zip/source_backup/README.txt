Java source and run scripts

Structures.java contains the Q1-Q4 data structures. HPC2.java runs the timed
workloads and writes one raw CSV file per question. CorrectnessTest.java runs
the separate semantic, stress, and structural checks.

The scripts expect these files in ~/Downloads/hpc/hpc2 and refuse to replace
existing raw result files. Run run_q1.sh, run_q3.sh, or run_q2_q4.sh there.
The last script runs Q2 and Q4 one after the other.

The enhanced correctness test was run on all three lab hosts after the
benchmark runs. Its test scope and source checksum are recorded in
../results/correctness_validation.txt. These are stress and invariant checks,
not a formal linearizability proof.

No compiled Java class files are included.
