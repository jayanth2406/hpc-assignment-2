Laptop-side backup of the current HPC Assignment 2 sources.

The laptop copy is the durable source/archive copy. RustDesk computers are compute hosts; source copies are staged there only to compile and run assigned jobs, while temporary benchmark outputs are copied back and verified here. Do not use compiled .class files in the submission.

Current source files: Structures.java, HPC2.java, CorrectnessTest.java.
Benchmark launch scripts: run_q1.sh, run_q3.sh, run_q2_q4.sh.
Remote working directory on each host: ~/Downloads/hpc/hpc2.
The laptop CorrectnessTest.java now includes exact concurrent list membership, stack value-preservation, per-producer FIFO, and paired elimination-stack checks. The active jobs were launched from the earlier synchronized copy; synchronize and run this enhanced test after the active benchmark scripts finish.
Current laptop CorrectnessTest.java SHA-256: 4442a108572fdfba35da5bb55b16ba2db5e01ab5148293ca8191122d82ebb79c
