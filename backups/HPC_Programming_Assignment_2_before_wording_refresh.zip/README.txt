HPC Programming Assignment 2
Concurrent data structures in Java

Team workspace
The laptop project folder is the durable source and results archive. The three RustDesk computers are compute hosts only. Benchmark working directory on every host:
  ~/Downloads/hpc/hpc2

Host allocation
  Q1, concurrent doubly linked list: Device 1
  Q3, concurrent queue: Device 2
  Q2, stack followed by Q4, elimination-backoff stack: Device 3
Each host runs only its assigned benchmark. Q2 and Q4 are sequential on Device 3.

Implementations
  Q1: Fine-grained lazy synchronized ordered doubly linked set; non-blocking copy-on-write doubly linked snapshots published by CAS.
  Q2: ReentrantLock stack; Treiber stack using AtomicReference and CAS.
  Q3: ReentrantLock queue; Michael-Scott queue using atomic head/tail links.
  Q4: Treiber stack; elimination-backoff stack using a CAS elimination array and timed offers.

Q1 tradeoff
The non-blocking list builds a complete immutable doubly linked version for each successful insert/delete and publishes it with one CAS. Both directions are consistent in every published state and readers traverse a stable version without locks. Updates are O(N), which is a correctness-first tradeoff and should be considered when interpreting its throughput. It is not the Sundell-Tsigas algorithm.
Unlike linked-node algorithms, this snapshot design has no transient marked nodes or helping-based physical unlink. A delete builds a new version without the key and linearizes when the new root is published by CAS; logical absence and removal from the current version happen together. Readers already holding an older immutable snapshot may finish on that version, which is safe because the operation intervals overlap. Old versions become collectible after readers release them.

Linearization points
  Lazy list: insert at linking the new node; delete at logical marking; contains at the decision made while holding and validating the adjacent-node locks.
  Snapshot list: successful update at the state-reference CAS; contains at the snapshot read; an unsuccessful update is determined by its observed snapshot.
  Lock stack: update at the top-reference mutation under the lock; peek/empty outcomes at the protected top read.
  Treiber stack: successful push/pop at the successful top CAS; empty pop and peek at the atomic top read.
  Lock queue: enqueue/dequeue at the protected link/head update; peek and empty dequeue at the protected head observation.
  Michael-Scott queue: enqueue at the successful tail.next CAS; dequeue at the successful head CAS; empty dequeue and peek at the validated head/next observation.
  Elimination stack: central operations linearize at the Treiber CAS; an eliminated push/pop pair linearizes at the successful WAITING-to-MATCHED CAS on its shared offer.

Benchmark method
The assignment configurations are N=1,000 and N=10,000; 50% prefill; workloads 0C-50I-50D, 50C-25I-25D, and 100C-0I-0D; 1,2,4,6,8,10,12,14,16 threads; five repetitions; ten seconds per run. System.nanoTime() is used for benchmark intervals. Prefill, deterministic trace creation, thread setup, and file writing are outside the timed interval. Throughput is operations divided by measured seconds, in MOPS. Speedup is average throughput at P threads divided by the corresponding one-thread average for the same implementation, N, and workload.

Validation and outputs
CorrectnessTest.java exercises empty/populated semantics, duplicate and near-sentinel boundary list keys, stack LIFO, queue FIFO, concurrent operation stress, exact concurrent list membership, stack value preservation, per-producer queue FIFO order, paired elimination-stack push/pop value delivery, and post-run structure invariants. Each benchmark row records operation count, elapsed nanoseconds, throughput, configuration, and verified status. The verified flag is based on worker completion plus structural validation; it is not a formal linearizability proof. The stronger value-preservation checks run separately from timed measurements.
The supplemental correctness suite passed on all three assigned hosts; the host names, source checksum, and validation scope are recorded in results/correctness_validation.txt.

Source backup: source_backup/
Raw result checkpoints: backups/
Host inventory: machine_specs.txt
Partial checkpoint validation: py scripts/check_checkpoint.py backups/<checkpoint>_q1_raw.csv ...
The complete raw datasets, averaged throughput/speedup tables, charts, and PDF report are stored in results/ after validation of all four questions. The GNUplot script is included for reproducibility; compiled .class files are excluded from the final package.

Local analysis
After all four complete raw CSVs are copied to results/:
  py scripts/summarize.py --q1 results/q1_raw.csv --q2 results/q2_raw.csv --q3 results/q3_raw.csv --q4 results/q4_raw.csv --out-dir results
Create results/plots/ before plotting.
  gnuplot -e "DATA='results/averages.csv'; OUT='results/plots'" scripts/plot_results.gp
Then build the HTML report from the validated averages and plots:
  py scripts/build_report.py
Use Microsoft Edge headless print-to-PDF on results/report.html to create results/report.pdf. Keep the report and plots in the laptop archive and include them with the sources, scripts, raw data, averages, validation report, and machine inventory in the final ZIP.

Report observed trends from the validated averages. Discuss lock contention, CAS retries and cache-coherence contention qualitatively; retry counts are not currently instrumented. Avoid claiming measured retry counts or formal linearizability testing.
