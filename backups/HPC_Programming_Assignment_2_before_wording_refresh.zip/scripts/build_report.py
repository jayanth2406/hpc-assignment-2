#!/usr/bin/env python3
"""Build a data-led HTML report from validated HPC2 averages and GNUplot images."""
import argparse
import csv
import html
import os
from datetime import datetime
from pathlib import Path

QUESTIONS = {
    "Q1": ("Concurrent doubly linked list", ("lazy", "lockfree")),
    "Q2": ("Concurrent stack", ("lock", "treiber")),
    "Q3": ("Concurrent queue", ("lock", "ms")),
    "Q4": ("Elimination-backoff stack", ("treiber", "elimination")),
}
WORKLOADS = ("0C-50I-50D", "50C-25I-25D", "100C-0I-0D")


def e(value):
    return html.escape(str(value))


def load_averages(path):
    with path.open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    if len(rows) != 432:
        raise SystemExit(f"Expected 432 average rows, found {len(rows)}")
    return rows


def row_for(rows, q, impl, n, workload, threads):
    matches = [r for r in rows if r["question"] == q
               and r["implementation"] == impl and int(r["n"]) == n
               and r["workload"] == workload and int(r["threads"]) == threads]
    if len(matches) != 1:
        raise SystemExit(f"Expected one average row for {q}/{impl}/N={n}/{workload}/T={threads}")
    return matches[0]


def build(args):
    rows = load_averages(args.averages)
    validation = args.validation.read_text(encoding="utf-8")
    if "PASS" not in validation or "2160" not in validation:
        raise SystemExit("Validation report does not confirm all 2160 raw runs")

    parts = ["""<!doctype html><html><head><meta charset="utf-8">
<style>
@page { size: A4; margin: 16mm 17mm; }
body { font-family: Georgia, 'Times New Roman', serif; font-size: 12pt; line-height: 1.35; color: #20242a; }
h1 { font-size: 23pt; color: #17324d; margin-bottom: 4pt; }
h2 { font-size: 18pt; color: #17324d; border-bottom: 1px solid #9ab0c3; padding-bottom: 4pt; }
h3 { font-size: 13pt; margin-bottom: 4pt; color: #254d70; }
p, li { margin-top: 4pt; margin-bottom: 5pt; }
table { width: 100%; border-collapse: collapse; font-size: 9.5pt; margin: 7pt 0 12pt; }
th, td { border: 1px solid #aeb8c2; padding: 4pt 5pt; text-align: right; }
th { background: #eaf0f5; color: #17324d; }
th:first-child, td:first-child { text-align: left; }
small { font-size: 9pt; color: #4d5965; }
.cover { min-height: 235mm; display: flex; flex-direction: column; justify-content: center; }
.question { page-break-before: always; }
.figures { display: flex; gap: 7mm; align-items: flex-start; }
.figure { width: 50%; }
.figure img { width: 100%; height: auto; }
.caption { font-size: 9pt; color: #4d5965; }
.note { background: #f1f5f8; padding: 7pt 9pt; border-left: 3px solid #477da8; }
</style></head><body>"""]

    max_records = []
    for q, (name, impls) in QUESTIONS.items():
        candidates = [r for r in rows if r["question"] == q and int(r["threads"]) > 1]
        best = max(candidates, key=lambda r: float(r["speedup"]))
        max_records.append((q, name, best))

    parts.append(f"""<section class="cover"><h1>Concurrent Data Structures in Java</h1>
<p><b>HPC Programming Assignment 2</b></p>
<p>Performance and scalability report</p>
<p>Experiment date: 2026-10-08</p>
<p>This report compares lazy/lock-based and non-blocking implementations using fixed-duration concurrent workloads on the IT Lab systems. All speedups use a one-thread baseline from the same implementation, problem size, and workload.</p>
<h2>Results at a glance</h2><table><tr><th>Problem</th><th>Highest observed speedup</th><th>Configuration</th></tr>""")
    for q, name, best in max_records:
        config = f'{best["implementation"]}, N={best["n"]}, {best["workload"]}, {best["threads"]} threads'
        parts.append(f"<tr><td>{e(q)}: {e(name)}</td><td>{float(best['speedup']):.2f}x</td><td>{e(config)}</td></tr>")
    parts.append("""</table><p class="note">These are observed maxima across the tested configurations, not claims of general scaling behavior. Full per-run measurements and averaged data are provided separately.</p>
<p><small>Machines: three identical Intel Core i7-12700 systems, 12 cores / 20 logical CPUs, 15.3 GiB RAM, Ubuntu, OpenJDK 1.8.0_352.</small></p></section>""")

    parts.append("""<section class="question"><h2>Method and implementation notes</h2>
<h3>Experimental protocol</h3>
<ul>
<li>Problem sizes: N = 1,000 and 10,000, with 50% prefilled before each run.</li>
<li>Workloads: 0C-50I-50D, 50C-25I-25D, and 100C-0I-0D.</li>
<li>Thread counts: 1, 2, 4, 6, 8, 10, 12, 14, and 16; five repetitions per configuration.</li>
<li>Each timed interval targets 10 seconds and uses System.nanoTime(). Prefill, deterministic workload traces, thread creation/setup, and CSV output are outside the measured workload interval.</li>
<li>Throughput is completed operation calls divided by the measured elapsed seconds, in millions of operations per second (MOPS). Speedup is the ratio of average throughput at P threads to the matching one-thread average.</li>
</ul>
<h3>Algorithms and linearization points</h3>
<ul>
<li><b>Q1 list:</b> the lazy list inserts at the protected predecessor-link update and deletes at the logical mark; unsuccessful insert/delete and contains linearize at the decision made in the validated, locked window. The non-blocking version publishes immutable doubly linked snapshots with one state CAS; successful updates linearize at that CAS, while unsuccessful updates and contains linearize at the observed snapshot read. It has no transient mark/help/unlink phase: delete omits the key from a new version and atomically publishes that version. In-flight readers may finish on an older immutable version. Copy-on-write updates are O(N), a deliberate correctness-first tradeoff rather than the Sundell-Tsigas linked-node algorithm.</li>
<li><b>Q2 stack:</b> lock-based push/pop linearize at the protected top mutation, with empty-pop and peek at the protected top observation. Treiber push/pop linearize at a successful top CAS; empty-pop and peek linearize at the atomic top observation.</li>
<li><b>Q3 queue:</b> lock-based enqueue/dequeue linearize at the protected link/head update, with empty-dequeue and peek at the protected head observation. Michael-Scott enqueue linearizes at the successful tail.next CAS and successful dequeue at the head CAS; empty-dequeue and peek linearize at the validated head/next observation.</li>
<li><b>Q4 elimination stack:</b> operations that use the central stack linearize at the Treiber top CAS (or the top observation for empty-pop/peek). A matched push/pop pair linearizes at the successful WAITING-to-MATCHED CAS on its shared elimination offer.</li>
</ul>
<p>Each recorded benchmark run passed worker and post-run structure validation. The separate correctness suite includes sequential empty/populated semantics, duplicate and near-sentinel list keys, exact concurrent list membership, stack value preservation under concurrent pushes, queue value preservation and per-producer FIFO order, paired elimination-stack push/pop value delivery, and mixed-operation stress. These checks are not a formal linearizability-history proof. CAS retry counts are not instrumented; contention and coherence effects are discussed qualitatively.</p></section>""")

    for q, (name, impls) in QUESTIONS.items():
        throughput_image = os.path.relpath(args.plots / (q + "_throughput.png"), args.output.parent).replace("\\", "/")
        speedup_image = os.path.relpath(args.plots / (q + "_speedup.png"), args.output.parent).replace("\\", "/")
        parts.append(f'<section class="question"><h2>{e(q)}: {e(name)}</h2>')
        parts.append("<p>Throughput and speedup are shown for both implementations, all three workload mixes, and both problem sizes. The speedup plots include the ideal linear reference.</p>")
        parts.append(f'<div class="figures"><div class="figure"><img src="{e(throughput_image)}"><p class="caption">Average throughput (MOPS).</p></div>')
        parts.append(f'<div class="figure"><img src="{e(speedup_image)}"><p class="caption">Throughput speedup versus one thread.</p></div></div>')
        parts.append('<h3>Representative mixed-workload results, N = 10,000</h3>')
        parts.append("<table><tr><th>Implementation</th><th>Threads</th><th>Avg throughput (MOPS)</th><th>Speedup</th></tr>")
        for impl in impls:
            for threads in (1, 4, 8, 16):
                r = row_for(rows, q, impl, 10000, "50C-25I-25D", threads)
                parts.append(f'<tr><td>{e(impl)}</td><td>{threads}</td><td>{float(r["avg_throughput_mops"]):.4f}</td><td>{float(r["speedup"]):.3f}x</td></tr>')
        parts.append("</table>")
        for impl in impls:
            all_impl = [r for r in rows if r["question"] == q and r["implementation"] == impl]
            best = max(all_impl, key=lambda r: float(r["avg_throughput_mops"]))
            parts.append(f'<p><b>{e(impl)}:</b> peak average throughput {float(best["avg_throughput_mops"]):.4f} MOPS at N={best["n"]}, {e(best["workload"])}, {best["threads"]} threads.</p>')
            baseline = {(int(r["n"]), r["workload"]): float(r["avg_throughput_mops"])
                        for r in all_impl if int(r["threads"]) == 1}
            at16 = [r for r in all_impl if int(r["threads"]) == 16]
            speedups16 = [float(r["avg_throughput_mops"]) / baseline[(int(r["n"]), r["workload"])]
                          for r in at16]
            mean16 = sum(speedups16) / len(speedups16)
            below = sum(value < 1.0 for value in speedups16)
            parts.append(f'<p>At 16 threads, <b>{e(impl)}</b> averaged {mean16:.2f}x speedup across the six size/workload settings (range {min(speedups16):.2f}x to {max(speedups16):.2f}x); {below} of six settings were below its one-thread throughput.</p>')
        if q == "Q4":
            q4_16 = {(int(r["n"]), r["workload"], r["implementation"]): float(r["avg_throughput_mops"])
                     for r in rows if r["question"] == q and int(r["threads"]) == 16}
            ratios = [q4_16[(n, w, "elimination")] / q4_16[(n, w, "treiber")]
                      for n in (1000, 10000) for w in WORKLOADS]
            parts.append(f'<p>At 16 threads, elimination outperformed Treiber in {sum(ratio > 1.0 for ratio in ratios)} of six matched configurations; the throughput ratio ranged from {min(ratios):.2f}x to {max(ratios):.2f}x, so its benefit was workload-dependent.</p>')
        parts.append("""<p class="note">Interpret scaling in light of the operation mix. A read-only mix avoids update coordination; update-heavy cases expose lock serialization, CAS retries, cache-line ownership traffic, and scheduler effects. An elimination array can reduce central-stack contention only when complementary push/pop operations meet; it may add overhead at lower contention.</p></section>""")

    parts.append("""<section class="question"><h2>Interpretation and limitations</h2>
<p>Compare each curve within its host and matching implementation, size, and workload. Read-heavy structures may scale differently from update-heavy structures: lock-based paths serialize on shared locks, while non-blocking paths can experience failed CAS retries and cache-coherence traffic on hot references. More threads can improve aggregate throughput, saturate, or regress depending on the critical path and scheduling overhead.</p>
<p>The Q1 copy-on-write doubly linked snapshot is expected to incur high update costs as N grows because a successful update rebuilds the full version. Q4 elimination is workload- and contention-dependent; its results should be judged against Treiber using the update-intensive workloads and higher thread counts, not presumed beneficial.</p>
<p>Per-run raw operation counts, elapsed times, and verification flags are supplied in CSV. Averages and speedups are independently validated from those raw rows. No absolute cross-host algorithm ranking is intended, even though the three hosts reported the same model.</p>
<p><b>Reproducibility:</b> Java source, correctness test, launch scripts, GNUplot script, machine inventory, raw data, averages, validation output, and plots accompany this report. Compiled class files are excluded from the submission package.</p></section></body></html>""")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(parts), encoding="utf-8")
    print(f"Wrote {args.output}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--averages", type=Path, default=Path("results/averages.csv"))
    p.add_argument("--validation", type=Path, default=Path("results/validation.txt"))
    p.add_argument("--plots", type=Path, default=Path("results/plots"))
    p.add_argument("--output", type=Path, default=Path("results/report.html"))
    build(p.parse_args())


if __name__ == "__main__":
    main()
